
# GrammarCheck_PowerIntern
Infosys PowerIntern project on NLP

# Install below python packages using PIP :

nltk,
pattern,
spellchecker

# To be executed during installation of project

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
